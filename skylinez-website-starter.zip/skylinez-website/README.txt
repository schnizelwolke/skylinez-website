SKYLINEZ WEBSITE STARTER
========================

Dateien:
- index.html  Inhalte und Seitenstruktur
- style.css   Farben, Layout und Design
- script.js   mobiles Menü und Jahreszahl

LOKAL ANSEHEN:
Öffne index.html in deinem Browser.

ANPASSEN:
1. Öffne index.html in einem Texteditor (z. B. VS Code).
2. Suche PLAYER NAME / In-game name und ersetze die Platzhalter.
3. Passe Rollen, Matchdaten und Teamtext an.
4. Ersetze contact@skylinez.example durch eure echte Kontaktadresse.
5. Für Spielerbilder kannst du Bilddateien in einen Ordner "images" legen und die Platzhalter-divs durch <img src="images/name.jpg" alt="Spielername"> ersetzen.

AUF GITHUB PAGES VERÖFFENTLICHEN:
1. Erstelle einen kostenlosen GitHub-Account: https://github.com/
2. Erstelle ein neues Repository namens skylinez-website.
3. Lade index.html, style.css und script.js hoch (README.txt optional).
4. Öffne im Repository Settings -> Pages.
5. Wähle bei Build and deployment: Deploy from a branch.
6. Wähle Branch "main" und Ordner "/ (root)", dann Save.
7. Nach dem Bereitstellen findest du die Seite unter:
   https://DEIN-GITHUB-NAME.github.io/skylinez-website/

HINWEISE:
- Alle Inhalte sind Platzhalter, keine echten Spieler oder Ergebnisse.
- Die Seite nutzt Google Fonts über eine externe Verbindung; bei Bedarf kann die Schrift lokal ersetzt werden.
- GitHub Pages ist für statische Webseiten geeignet. Für Formulare, Logins oder dynamische Daten brauchst du zusätzliche Dienste.
